let currentBoard = '';
let currentPost = null;
let isWritingPost = false;

function selectBoard(board) {
    if (!isWritingPost) {
        // 게시판 선택 상태
        currentBoard = board;
        document.getElementById('title').textContent = board.toUpperCase() + ' 게시판';
        fetch(`/api/posts/${board}`)
            .then(response => response.json())
            .then(posts => renderPostList(posts));
    } else {
        // 글쓰기 상태에서는 "글쓰기" 제목 유지
        document.getElementById('title').textContent = '글쓰기';
    }
}

function renderPostList(posts) {
    const postList = document.getElementById('postList');
    postList.innerHTML = '';
    posts.forEach(post => {
        const li = document.createElement('li');

        const title = document.createElement('span');
        title.textContent = post.title;
        title.style.fontSize = '20px';
        title.style.fontWeight = 'bold';

        const details = document.createElement('span');
        details.textContent = `좋아요: ${post.likes} 댓글: ${post.comments.length}`;
        details.style.display = 'block';
        details.style.marginTop = '5px';
        li.onclick = () => showPostDetail(post);
        li.appendChild(title);
        li.appendChild(details);
        postList.appendChild(li);
        postList.appendChild(document.createElement('hr'));
    });
    document.getElementById('boardSelection').style.display = 'none';
    document.getElementById('postListContainer').style.display = 'block';
}

function addPost() {
    const title = document.getElementById('titleCreate').value.trim();
    const content = document.getElementById('contentCreate').value.trim();

    // 제목과 본문 유효성 검사
    if (!title) {
        alert('제목이 없습니다. 제목을 입력해주세요.');
        return;
    }
    else if (!content) {
        alert('본문이 없습니다. 본문 내용을 입력해주세요.');
        return;
    }

    // 게시글 데이터 생성
    const postData = {
        title,
        content,
        comments: [],
        likes: 0,
        createdAt: new Date().toISOString(),
        scraped: false,
        author: 'someone', // 작성자 이름 추가
    };

    // 서버에 게시글 데이터 전송
    fetch(`/api/posts/${currentBoard}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(postData),
    })
        .then((response) => {
            if (response.ok) {
                // 게시글 추가 성공 시
                goBackToPostList();
                selectBoard(currentBoard);
            } else {
                alert('게시글 추가에 실패했습니다. 다시 시도해주세요.');
            }
        })
        .catch((error) => {
            console.error('게시글 추가 오류:', error);
            alert('게시글 추가 중 오류가 발생했습니다.');
        });
}



function showPostDetail(post) {
    currentPost = post;
    document.getElementById('postAuthor').textContent = post.author;
    document.getElementById('postTitleDetail').textContent = post.title;
    document.getElementById('postContentDetail').textContent = post.content;
    document.getElementById('likeCount').textContent = post.likes;
    renderComments(post.comments);
    document.getElementById('postListContainer').style.display = 'none';
    document.getElementById('postDetailContainer').style.display = 'block';
    document.getElementById('createBar').style.display = 'block';
    document.getElementById('menuBar').style.display = 'none';
}

function renderComments(comments) {
    const commentList = document.getElementById('commentList');
    commentList.innerHTML = '';
    comments.forEach(comment => {
        const li = document.createElement('li');
        li.textContent = comment;
        commentList.appendChild(li);
        commentList.appendChild(document.createElement('hr'));
    });
}

function addComment() {
    const comment = document.getElementById('commentInput').value;
    fetch(`/api/posts/${currentBoard}/${currentPost.title}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ comment })
    }).then(response => response.json())
      .then(post => {
          renderComments(post.comments);
          document.getElementById('commentInput').value = ''; // 입력 필드 초기화
      });
}

function likePost() {
    currentPost.likes++;
    updatePost(currentPost);
}

function scrapPost() {
    // 스크랩 상태를 반전시킴
    currentPost.scraped = !currentPost.scraped;
    updatePost(currentPost);
}

function updatePost(post) {
    fetch(`/api/posts/${currentBoard}/${currentPost.title}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            newTitle: post.title,
            content: post.content,
            likes: post.likes,
            scraped: post.scraped
        })
    }).then(response => response.json())
      .then(updatedPost => {
          currentPost = updatedPost;
          showPostDetail(updatedPost);  // 변경된 정보를 다시 화면에 반영
      });
}

function deletePost() {
    fetch(`/api/posts/${currentBoard}/${currentPost.title}`, { method: 'DELETE' }).then(() => {
        goBackToPostList();
        selectBoard(currentBoard);
    });
}

function editPost() {
    document.getElementById('editTitle').value = currentPost.title;
    document.getElementById('editContent').value = currentPost.content;
    document.getElementById('postDetailContainer').style.display = 'none';
    document.getElementById('editFormContainer').style.display = 'block';

    document.getElementById('menuBar').style.display = 'none';
    document.getElementById('back-btn').style.display = 'none';
    document.getElementById('createBar').style.display = 'none';
    document.getElementById('closeBar').style.display = 'block';
    document.getElementById('noneImg').style.display = 'block';
}

function savePost() {
    const newTitle = document.getElementById('editTitle').value;
    const content = document.getElementById('editContent').value;
    fetch(`/api/posts/${currentBoard}/${currentPost.title}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ newTitle, content })
    }).then(response => response.json())
      .then(updatedPost => {
          currentPost = updatedPost;
          goBackToPostList();
          selectBoard(currentBoard);
      });
}

function goToCreatePost() {
    const titleElement = document.getElementById('titleCreate');
    const contentElement = document.getElementById('contentCreate');
    isWritingPost = true;
    
    if (titleElement) titleElement.value = '';
    if (contentElement) contentElement.value = '';
    document.getElementById('title').textContent = '글 쓰기';
    document.getElementById('postListContainer').style.display = 'none';
    document.getElementById('menuBar').style.display = 'none';
    document.getElementById('back-btn').style.display = 'none';
    document.getElementById('formContainer').style.display = 'block';
    document.getElementById('closeBar').style.display = 'block';
    document.getElementById('noneImg').style.display = 'block';
}

function goBackToPostList() {
    isWritingPost = false;
    currentPost = null;
    document.getElementById('title').textContent = currentBoard.toUpperCase() + ' 게시판';
    document.getElementById('formContainer').style.display = 'none';
    document.getElementById('postDetailContainer').style.display = 'none';
    document.getElementById('editFormContainer').style.display = 'none';
    document.getElementById('menuBar').style.display = 'block';
    document.getElementById('closeBar').style.display = 'none';
    document.getElementById('noneImg').style.display = 'none';
    document.getElementById('back-btn').style.display = 'block';
    document.getElementById('createBar').style.display = 'none';
    document.getElementById('postListContainer').style.display = 'block';
}


function goBackToBoardSelection() {
    isWritingPost = false;
    document.getElementById('title').textContent = '게시판';
    document.getElementById('boardSelection').style.display = 'block';
    document.getElementById('postListContainer').style.display = 'none';
}

function backButton() {
    if (isWritingPost) {
        // 글 작성 중일 때는 게시글 목록으로 돌아가기
        goBackToPostList();
    } else if (currentPost) {
        // 특정 게시글을 보고 있을 때는 게시글 목록으로 돌아가기
        goBackToPostList();
    } else if (currentBoard) {
        // 특정 게시판에 있을 때는 게시판 선택 페이지로 돌아가기
        currentBoard = ''; // 현재 선택된 게시판 초기화
        goBackToBoardSelection();
    } else {
        console.log("else");
    }
}


