const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3001;

app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());

const dataFilePath = path.join(__dirname, 'data', 'posts.json');

// 파일에서 게시글 읽기
function readPosts() {
    return JSON.parse(fs.readFileSync(dataFilePath, 'utf8'));
}

// 게시글을 파일에 저장하기
function writePosts(posts) {
    fs.writeFileSync(dataFilePath, JSON.stringify(posts, null, 2), 'utf8');
}

// 게시글 목록 가져오기 (정렬 추가)
app.get('/api/posts/:board', (req, res) => {
    const { board } = req.params;
    const { sortBy } = req.query; // sortBy는 최신순, 좋아요순 등을 선택하는 파라미터

    const posts = readPosts();
    let boardPosts = posts[board] || [];

    // 정렬 조건에 따른 정렬
    if (sortBy === 'latest') {
        boardPosts = boardPosts.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)); // 최신순 정렬
    } else if (sortBy === 'likes') {
        boardPosts = boardPosts.sort((a, b) => b.likes - a.likes); // 좋아요 순 정렬
    }

    res.json(boardPosts);
});

// 게시글 추가
app.post('/api/posts/:board', (req, res) => {
    const { board } = req.params;
    const newPost = req.body;
    const posts = readPosts();

    if (!posts[board]) posts[board] = [];

    // 새로운 게시글에 기본 값 설정
    newPost.likes = 0;  // 좋아요 초기값
    newPost.createdAt = new Date().toISOString();  // 작성 시간

    posts[board].push(newPost);
    writePosts(posts);

    res.status(201).json(posts[board]);
});

// 게시글 좋아요 증가
app.post('/api/posts/:board/:title/like', (req, res) => {
    const { board, title } = req.params;
    const posts = readPosts();

    const post = posts[board]?.find(post => post.title === title);
    if (!post) return res.status(404).send('게시글을 찾을 수 없습니다.');

    post.likes += 1;
    writePosts(posts);

    res.json(post);
});

// 게시글 스크랩
app.post('/api/posts/:board/:title/scrap', (req, res) => {
    const { board, title } = req.params;
    const posts = readPosts();

    const post = posts[board]?.find(post => post.title === title);
    if (!post) return res.status(404).send('게시글을 찾을 수 없습니다.');

    post.scraped = true;  // 스크랩 상태 추가
    writePosts(posts);

    res.json(post);
});

// 게시글 수정
app.put('/api/posts/:board/:title', (req, res) => {
    const { board, title } = req.params;
    const { newTitle, content, likes, scraped } = req.body;
    const posts = readPosts();

    const post = posts[board]?.find(post => post.title === title);
    if (!post) return res.status(404).send('게시글을 찾을 수 없습니다.');

    post.title = newTitle || post.title;
    post.content = content || post.content;
    post.likes = likes !== undefined ? likes : post.likes;
    post.scraped = scraped !== undefined ? scraped : post.scraped;
    writePosts(posts);

    res.json(post);
});

// 게시글 삭제
app.delete('/api/posts/:board/:title', (req, res) => {
    const { board, title } = req.params;
    const posts = readPosts();

    const index = posts[board]?.findIndex(post => post.title === title);
    if (index === -1 || index === undefined) return res.status(404).send('게시글을 찾을 수 없습니다.');

    posts[board].splice(index, 1);
    writePosts(posts);

    res.status(204).send();
});

// 댓글 추가
app.post('/api/posts/:board/:title/comments', (req, res) => {
    const { board, title } = req.params;
    const { comment } = req.body;
    const posts = readPosts();

    const post = posts[board]?.find(post => post.title === title);
    if (!post) return res.status(404).send('게시글을 찾을 수 없습니다.');

    post.comments.push(comment);
    writePosts(posts);

    res.json(post);
});

app.listen(PORT, () => {
    console.log(`서버가 http://localhost:${PORT} 에서 실행 중입니다.`);
});
